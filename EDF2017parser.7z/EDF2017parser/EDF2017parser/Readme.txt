--First
If the file is SGSL compressed, the conversion will not work.
If it is SGSL compressed, the first 4 bytes of the file are SGSL (0x53 0x47 0x53 0x4C).

--Supported File Formats

*dxb/dxm
can be decompress/compress.

*xPath
can be decompress/compress.

--Unsupported File Formats

*sgo
can be decompress/compress by using SGOTTv1.10.2.(https://github.com/zeddidragon/sgott/releases)
when json => SGO, "extra5" must be replaced with "ptr".

*bvm
For Mr. S's tool(https://github.com/mp-s/edftools/releases),
replacing the included files works except for a few missions.